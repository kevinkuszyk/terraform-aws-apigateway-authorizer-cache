
exports.handler = async function(event) {
    return ok('foo', event.methodArn);
}

function ok(principalId, resource) {
    return getPolicy(principalId, resource, 'Allow');
}

function getPolicy(principalId, resource, effect) {
    return {
        principalId: principalId,
        policyDocument: {
            Version: '2012-10-17',
            Statement: [
                {
                    Action: 'execute-api:Invoke',
                    Effect: effect,
                    Resource: resource
                }
            ]
        }
    };
}